﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_Move : MonoBehaviour {
    public Player_UI playerUI;
    public float speed = 3.0f;
	// Use this for initialization
	void Start () {
		
	}
	// Update is called once per frame
	void Update () {
        Move();
        MoveClamp();
	}
    void Move()
    {
        if (Input.GetKey(KeyCode.UpArrow)) // 윗 방향키를 입력했을때
        {
            transform.Translate(Vector2.up * speed * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.DownArrow)) // 밑 방향키를 입력했을때
        {
            transform.Translate(Vector2.down * speed * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.RightArrow)) // 우측 방향키를 입력했을때
        {
            transform.Translate(Vector2.right * speed * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.LeftArrow)) // 왼쪽 방향키를 입력했을때
        {
            transform.Translate(Vector2.left * speed * Time.deltaTime);
        }
    }
    void MoveClamp()
    {
        Vector2 left = Camera.main.ViewportToWorldPoint(new Vector2(0, 0));
        Vector2 right = Camera.main.ViewportToWorldPoint(new Vector2(1, 1));

        Vector2 player = transform.position;

        player.x = Mathf.Clamp(player.x, left.x + 0.8f, right.x - 0.8f);
        player.y = Mathf.Clamp(player.y, left.y + 1, right.y - 2);

        transform.position = player;
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Enemy") )
        {
            playerUI.Hit(10);
            Debug.Log("충돌 후 Player 체력 : " + playerUI.PlayerHP);
        }
    }
}

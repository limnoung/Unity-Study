﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_Data : MonoBehaviour
{
    private int HP;

    public Enemy_Data(int _HP) {
        HP = _HP;
    }
    public int hp
    {
        get
        {
            return HP;
        }
        set
        {
            HP = value;
        }
    }
}

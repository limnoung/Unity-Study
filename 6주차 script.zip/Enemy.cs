﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour {
    public int HP;
    public int MaxHP;
    private Enemy_Data enemyData;
	// Use this for initialization
	void Start () {
        enemyData = new Enemy_Data(HP);
        Debug.Log("enemy 현재 체력 : " + enemyData.hp);
        MaxHP = HP;
	}
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("PlayerMissile"))
        {
            Debug.Log("미사일 충돌");
            enemyData.hp -= 10;
            HP = enemyData.hp;
            Debug.Log("충돌 후 enemy 체력 : " + enemyData.hp);
        }
    }
    // Update is called once per frame
    void Update () {
        if (enemyData.hp <= 0)
        {
            Destroy(gameObject);
        }
	}
}

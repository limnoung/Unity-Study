﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Player_UI : MonoBehaviour {
    public GameObject Player;
    public int PlayerHP;
    public Slider HPbar;
    private Player_Data playerData;
	// Use this for initialization
	void Start () {
        playerData = new Player_Data(PlayerHP);
        HPbar.maxValue = PlayerHP;
        HPbar.value = PlayerHP;
	}
	public void Hit(int _damage)
    {
        playerData.hp -= _damage;
    }
    void HPCheck()
    {
        PlayerHP = playerData.hp;
        HPbar.value = PlayerHP;
        if (PlayerHP <= 0)
        {
            PlayerHP = 0;
            Destroy(Player);
        }
    }
	// Update is called once per frame
	void Update () {
        HPCheck();
	}
}

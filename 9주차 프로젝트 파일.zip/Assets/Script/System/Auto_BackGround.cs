﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Auto_BackGround : MonoBehaviour
{

    public GameObject BackGround; // 배경 이미지
    private List<GameObject> background = new List<GameObject>(); // 배경들의 배열 생성
    private int Phase = 0; // 배경이 얼마나 생성됬는지 알수있게 해주는 인덱스 역할
    private float InstantiateYPos = 0f; // 배경 생성위치
    private float CurrentYPos; // 현재 카메라의 위치
    private bool isEnabled = true;
    private float size = 36.3f;
    // Update is called once per frame
    void Update()
    {
        PositionCheck();
    }
    void PositionCheck()
    {
        CurrentYPos = Camera.main.ViewportToWorldPoint(new Vector2(0, 0)).y;
        // 배경 이미지 배열 사이즈가 2 이상이고 배경을 통과했을때 필요없는 배경 삭제하기
        if (background.Count >= 2 && CurrentYPos > InstantiateYPos - size)
        {
            GameObject removeItem = background[0];
            background.RemoveAt(0);
            Destroy(removeItem);
        }
        // 배경 이미지의 끝지점에서 다시 배경 생성
        CurrentYPos = Camera.main.ViewportToWorldPoint(new Vector2(1, 1)).y;
        if (CurrentYPos / size > Phase)
        {
            if (isEnabled)
            {
                StartCoroutine(InstantiateBackGround());
            }
        }
    }
    IEnumerator InstantiateBackGround()
    {
        isEnabled = false;
        GameObject temp = Instantiate(BackGround) as GameObject;
        temp.transform.position = new Vector3(0f, InstantiateYPos, 0f);
        background.Add(temp);
        InstantiateYPos += size;
        Phase++;
        yield return new WaitForSeconds(1f);
        isEnabled = true;
    }
}

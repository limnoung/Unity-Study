﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Player_UI : MonoBehaviour {
    public GameObject Player;
    public Text ScoreNum;
    public int PlayerHP;
    public Slider HPbar;
    private Player_Data playerData;
	// Use this for initialization
	void Start () {
        playerData = new Player_Data(PlayerHP);
        HPbar.maxValue = PlayerHP;
        HPbar.value = PlayerHP;
        Score = 0;
	}
    public int Score { get; set; }
	public void Hit(int _damage)
    {
        playerData.hp -= _damage;
    }
    public void AddScore(int score)
    {
        Score += score;
        ScoreNum.text = Score.ToString();
    }
    void HPCheck()
    {
        PlayerHP = playerData.hp;
        HPbar.value = PlayerHP;
        if (PlayerHP <= 0)
        {
            PlayerHP = 0;
            Destroy(Player);
        }
    }
	// Update is called once per frame
	void Update () {
        HPCheck();
	}
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_Missile_Move : MonoBehaviour
{
    public float MoveSpeed;
    private Vector3 toPlayer;
    private float DestroyYPos;
    private float DestroyXPos_L = -3.5f;
    private float DestroyXPos_R = 3.5f;
    private void Start()
    {
        if (GameObject.Find("Airplane"))
            toPlayer = (GameObject.Find("Airplane").transform.position - gameObject.transform.position).normalized;
    }
    // Update is called once per frame
    void Update()
    {
        DestroyYPos = Camera.main.ViewportToWorldPoint(new Vector2(0, 0)).y;
        if (transform.position.y < DestroyYPos || transform.position.x < DestroyXPos_L || transform.position.x > DestroyXPos_R)
        {
            GetComponent<Collider2D>().enabled = false;
        }
        transform.Translate(toPlayer * MoveSpeed * Time.deltaTime);
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player") || collision.CompareTag("Wall"))
        {
            GetComponent<Collider2D>().enabled = false;
        }
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour {
    public int HP;
    public int MaxHP;
    private Enemy_Data enemyData;
    private Enemy_Fire enemyFire;
    public float Delay;
	// Use this for initialization
	void Start () {
        enemyData = new Enemy_Data(HP);
        enemyFire = GetComponent<Enemy_Fire>();
        MaxHP = HP;

	}
    public void Move()
    {
        iTween.MoveTo(gameObject, iTween.Hash("Path",iTweenPath.GetPath(GetComponent<iTweenPath>().pathName), "time", 10f,"Delay",Delay-1f));
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("PlayerMissile"))
        {
            enemyData.hp -= collision.GetComponent<Missile_Move>().MissilePower;
            HP = enemyData.hp;
        }
    }
    // Update is called once per frame
    void Update () {
        if(Camera.main.ViewportToWorldPoint(new Vector2(0, 0)).y- gameObject.transform.position.y > 2f || enemyData.hp<=0)
        {
            if (enemyData.hp <= 0)
            {
                GameObject.Find("Player_Event").GetComponent<Player_UI>().AddScore(100);
                enemyFire.MissileClear();
                Destroy(gameObject);
            }
            else if (enemyFire.MissileNum == 0)
            {
                enemyFire.MissileClear();
                Destroy(gameObject);
            }
        }
	}
}

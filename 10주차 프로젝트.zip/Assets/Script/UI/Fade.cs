﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Fade : MonoBehaviour {
    Image image;
    Text text;
    float a;
    bool isEnabled = false;
    private void Start()
    {
        image = gameObject.GetComponent<Image>();
        text = transform.Find("Text").GetComponent<Text>();
        a = 0f;
        image.color = new Color(0, 0, 0, 0);
        text.color = new Color(1, 1, 1, 0);


    }
    void ValueChange()
    {
        if (text.color.a <= 0.99f)
        {
            a += 0.01f;
            if (image.color.a <= 1f)
                image.color = new Color(0, 0, 0, a);
            if (a >= 0.5f && a <= 1.5f)
                text.color = new Color(1, 1, 1, (a * 2 - 1f) / 2);
        }
        else
        {
           StartCoroutine(SceneChange());
            if (isEnabled)
            {
                StopAllCoroutines();
                SceneManager.LoadScene(0);
            }
        }
    }
    // Update is called once per frame
    void Update () {
        ValueChange();
    }
    IEnumerator SceneChange()
    {
        yield return new WaitForSeconds(3f);
        isEnabled = true;
    }
}

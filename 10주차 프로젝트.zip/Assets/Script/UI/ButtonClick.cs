﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;
using UnityEngine.UI;

public class ButtonClick : MonoBehaviour {
    public void OnClickStart()
    {
        SceneManager.LoadScene(1);
    }
    public void OnClickScoreBoard()
    {
        GameObject MainUI = transform.parent.gameObject;
        GameObject ScoreBoardUI = transform.parent.parent.Find("ScoreBoardUI").gameObject;
        MainUI.SetActive(false);
        ScoreBoardUI.SetActive(true);
        ScoreBoardUI.transform.Find("ScoreBoard").GetComponent<Text>().text = DataSaveLoad.Load();
    }
    public void OnClickExit()
    {
        Application.Quit();
    }
    public void OnClickBack()
    {
        GameObject MainUI = transform.parent.parent.Find("MainUI").gameObject;
        GameObject ScoreBoardUI = transform.parent.gameObject;
        ScoreBoardUI.SetActive(false);
        MainUI.SetActive(true);
    }
}

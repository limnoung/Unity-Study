﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Security.Cryptography;
using System.Xml;
using System;

public class RecItem
{
    public string Date;
    public int Score;
}

public sealed class ItemIO
{
    public static void Write(List<RecItem> ScoreList, string filePath)
    {
        XmlDocument Document = new XmlDocument();
        XmlElement ScoreListElement = Document.CreateElement("ScoreList");
        Document.AppendChild(ScoreListElement);

        foreach (RecItem Item in ScoreList)
        {
            XmlElement ScoreElement = Document.CreateElement("Score");
            ScoreElement.SetAttribute("Date", Item.Date);
            ScoreElement.SetAttribute("Score", Item.Score.ToString());
            ScoreListElement.AppendChild(ScoreElement);
        }
        string data = DataEncryptDecrypt.encryData(ScoreListElement.InnerXml);
        ScoreListElement.RemoveAll();
        ScoreListElement.InnerText = data;
        Document.Save(filePath);
    }

    public static List<RecItem> Read(string filePath)
    {
        XmlDocument Document = new XmlDocument();
        Document.Load(filePath);
        XmlElement ScoreListElement = Document.DocumentElement;

        string data = DataEncryptDecrypt.Decrypt(ScoreListElement.InnerText);
        ScoreListElement.InnerXml = data;

        List<RecItem> ScoreList = new List<RecItem>();

        foreach (XmlElement ScoreElement in ScoreListElement.ChildNodes)
        {
            RecItem Item = new RecItem();
            Item.Date = ScoreElement.GetAttribute("Date");
            Item.Score = System.Convert.ToInt32(ScoreElement.GetAttribute("Score"));
            ScoreList.Add(Item);
        }
        return ScoreList;
    }
}
public class DataEncryptDecrypt
{
    public static string encryData(string toEncrypt)
    {
        byte[] keyArray = UTF8Encoding.UTF8.GetBytes("12345678901234567890123456789012");

        byte[] toEmcryptArray = UTF8Encoding.UTF8.GetBytes(toEncrypt);
        RijndaelManaged rDel = new RijndaelManaged();

        rDel.Key = keyArray;
        rDel.Mode = CipherMode.ECB;

        rDel.Padding = PaddingMode.PKCS7;

        ICryptoTransform cTransform = rDel.CreateEncryptor();

        byte[] resultArray = cTransform.TransformFinalBlock(toEmcryptArray, 0, toEmcryptArray.Length);

        return Convert.ToBase64String(resultArray, 0, resultArray.Length);
    }

    public static string Decrypt(string toDecrypt)
    {
        byte[] keyArray = UTF8Encoding.UTF8.GetBytes("12345678901234567890123456789012");

        byte[] toEncryptArray = Convert.FromBase64String(toDecrypt);

        RijndaelManaged rDel = new RijndaelManaged();
        rDel.Key = keyArray;
        rDel.Mode = CipherMode.ECB;

        rDel.Padding = PaddingMode.PKCS7;

        ICryptoTransform cTransform = rDel.CreateDecryptor();

        byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);

        return UTF8Encoding.UTF8.GetString(resultArray);
    }
}

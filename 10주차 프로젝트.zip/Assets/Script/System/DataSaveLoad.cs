﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using System.Text;
using System.IO.IsolatedStorage;

public class DataSaveLoad
{
    static readonly string filePath = "/Score.xml";
    public static void Save()
    {
        RecItem item = new RecItem();
        List<RecItem> itemList = new List<RecItem>();

        try
        {
            itemList = ItemIO.Read(Application.streamingAssetsPath + filePath);
            
            item.Date = System.DateTime.Now.ToString("MM-dd / HH-mm");
            item.Score = int.Parse(GameObject.Find("Player_Event").GetComponent<Player_UI>().ScoreNum.text.ToString());
            itemList.Add(item);
            itemList.Sort(delegate (RecItem a, RecItem b)
            {
                if (a.Score < b.Score) return 1;
                else if (a.Score > b.Score) return -1;
                return 0;
            });
            if (itemList.Count > 10)
                itemList.RemoveAt(itemList.Count - 1);
            ItemIO.Write(itemList, Application.streamingAssetsPath + filePath);
        }
        catch(System.IO.FileNotFoundException)
        {
            item.Date = System.DateTime.Now.ToString("MM-dd / HH-mm");
            item.Score = int.Parse(GameObject.Find("Player_Event").GetComponent<Player_UI>().ScoreNum.text);
            itemList.Add(item);
            ItemIO.Write(itemList, Application.streamingAssetsPath + filePath);
        }
        catch (System.IO.DirectoryNotFoundException)
        {
            System.IO.DirectoryInfo di = new System.IO.DirectoryInfo(Application.streamingAssetsPath);
            di.Create();
            item.Date = System.DateTime.Now.ToString("MM-dd / HH-mm");
            item.Score = int.Parse(GameObject.Find("Player_Event").GetComponent<Player_UI>().ScoreNum.text);
            itemList.Add(item);
            ItemIO.Write(itemList, Application.streamingAssetsPath + filePath);
        }
    }
    public static string Load()
    {
        string temp = null;
        List<RecItem> itemList;
        try
        {
            itemList = ItemIO.Read(Application.streamingAssetsPath + filePath);
            for (int i = 0; i < itemList.Count; i++)
            {
                RecItem item = itemList[i];
                temp += itemList[i].Date + "    " + itemList[i].Score + "\n";
            }
            return temp;
        }
        catch (System.IO.FileNotFoundException )
        {
            temp = "Score Data is not found";
            return temp;
        }
        catch (System.IO.DirectoryNotFoundException)
        {
            System.IO.DirectoryInfo di = new System.IO.DirectoryInfo(Application.streamingAssetsPath);
            di.Create();
            temp = "Score Data is not found";
            return temp;
        }
    }
}

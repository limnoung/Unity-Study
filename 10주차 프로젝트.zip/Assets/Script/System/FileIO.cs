﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FileIO : MonoBehaviour {
    public GameObject EnemyObject; // 적 오브젝트

    private TextAsset file; // csv 파일
    private string[] data_line; // csv 파일을 엔터단위로 끊은 데이터
    private string[] data_pos; // 엔터단위로 끊은 데이터 가운데 좌표를 뽑아낸 데이터
    private GameObject[] enemy; // 실제로 맵에 생성할 적
    private iTweenPath enemyPath; // enemy의 itweenPath 
    private float MoveSpeed; // 배경의 이동속도
    // Use this for initialization
    void Start()
    {
        MoveSpeed = GameObject.Find("Player").GetComponent<AutoMove>().MoveSpeed;
        // Resources 폴더안에 EnemySpawnPoint 라는 파일을 TextAsset이란 형식으로 읽어들인다.
        file = Resources.Load("EnemySpawnPoint", typeof(TextAsset)) as TextAsset;
        //엔터 단위로 나눠서 data_line에 넣어준다. 
        data_line = file.text.Split('\n');
        // 적의 숫자를 구하기
        int length = data_line.Length;
        // 적의 숫자만큼 배열 초기화
        enemy = new GameObject[length];
        Debug.Log(length);
        if(EnemyObject != null)
        {
            for(int i=0; i<length; i++)
            {
                //엔터단위로 나뉜 데이터 중 좌표를 뽑아내서 데이터를 넣는다.
                data_pos = data_line[i].Split(',');
                int length_pos = (data_pos.Length-1) / 2;
                // 적을 생성하기 전 Delay Time을 확인한다.
                float Delay = float.Parse(data_pos[data_pos.Length - 1]);
                // 적을 생성한다.
                enemy[i] = Instantiate(EnemyObject) as GameObject;
                enemy[i].GetComponent<Enemy>().Delay = Delay;
                // 생성한 적에게 좌표를 부여합니다.
                enemy[i].transform.position = new Vector3(float.Parse(data_pos[0]), float.Parse(data_pos[1])+Delay*MoveSpeed, 0f);
                // 적의 itweenPath 조정
                enemyPath = enemy[i].GetComponent<iTweenPath>();
                enemyPath.nodes.Clear();
                enemyPath.nodeCount = length_pos;
                for(int j=0; j<length_pos; j++)
                {
                    enemyPath.nodes.Add(new Vector3(float.Parse(data_pos[j * 2]), float.Parse(data_pos[j * 2 + 1]) + Delay * MoveSpeed, 0f));
                }
                enemy[i].GetComponent<Enemy>().Move();
            }
        }
        
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_Data : MonoBehaviour {
    public Player_Data(int _HP)
    {
        Hp = _HP;
    }
    public int Hp { get; set; }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_Fire : MonoBehaviour
{
    private const float DISTANCE_RECOG = 5f; // 적이 미사일을 발사하는 절대 거리

    public GameObject MissileObject; // 적이 발사하는 미사일
    public Transform MissileLocation; // 적의 미사일이 발사되는 위치
    public int MissileMaximumPool; // 적의 미사일 오브젝트가 생성되는 최대 개수
    public float FireRateTime; // 적의 미사일이 발사되는 속도
    public int MissileNum; // 발사된 미사일의 개수

    private GameObject[] Missile; // 미사일 오브젝트를 생성하여 저장할 배열
    private MemoryPool MPool; // 미사일 오브젝트를 관리할 메모리풀
    private GameObject Player; // 플레이어의 위치
    private bool FireEnabled; // 미사일을 발사할수 있는지의 여부
    private bool FireState; // 미사일이 발사되고 있는지의 여부

    // Use this for initialization
    void Start()
    {
        MPool = new MemoryPool();
        MPool.Create(MissileObject, MissileMaximumPool);
        Missile = new GameObject[MissileMaximumPool];
        Player = GameObject.FindGameObjectWithTag("Player");
        FireEnabled = false;
        FireState = false;
        MissileNum = 0;
    }

    void OnApplicationQuit()
    {
        MPool.Dispose();
    }
    void OnTriggerEnter2D(Collider2D collider)
    {
        // 플레이어의 미사일과 충돌하였다면
        if (collider.GetComponent<Collider2D>().CompareTag("PlayerMissile"))
        {
            for (int i = 0; i < MissileMaximumPool; i++)
            {
                if (Missile[i])
                {
                    if (Missile[i].GetComponent<Collider2D>().enabled == false)
                    {
                        Missile[i].GetComponent<Collider2D>().enabled = true;
                        MPool.RemoveItem(Missile[i]);
                        Missile[i] = null;
                        MissileNum--;
                    }
                }
            }
        }
    }
    void DistanceCheck()
    {
        if (Player)
        {
            if (Mathf.Abs(transform.position.y - Player.transform.position.y) < DISTANCE_RECOG)
            {
                FireEnabled = true;
            }
            else
                FireEnabled = false;
        }
    }
    void MissileFire()
    {
        // 미사일 발사가 허용 된다면
        if (FireEnabled)
        {
            // 현재 미사일을 발사하고 있지 않다면
            if (!FireState)
            {
                StartCoroutine(FireCycleControl());
                for (int i = 0; i < MissileMaximumPool; i++)
                {
                    if (Missile[i] == null)
                    {
                        Missile[i] = MPool.NewItem();
                        Missile[i].transform.position = MissileLocation.transform.position;
                        MissileNum++;
                        break;
                    }
                }
            }
        }
        // 오브젝트 객체를 회수한다.
        for (int i = 0; i < MissileMaximumPool; i++)
        {
            if (Missile[i])
            {
                if (Missile[i].GetComponent<Collider2D>().enabled == false)
                {
                    Missile[i].GetComponent<Collider2D>().enabled = true;
                    MPool.RemoveItem(Missile[i]);
                    Missile[i] = null;
                    MissileNum--;
                }
            }
        }

    }
    public void MissileClear()
    {
        MPool.Dispose();
    }
    // Update is called once per frame
    void Update()
    {
        DistanceCheck();
        MissileFire();
    }

    IEnumerator FireCycleControl()
    {
        FireState = true;
        yield return new WaitForSeconds(FireRateTime);
        FireState = false;
    }
}

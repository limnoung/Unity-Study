﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_Data : MonoBehaviour
{
    public Enemy_Data(int _HP) {
        Hp = _HP;
    }
    public int Hp { get; set; }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_UI : MonoBehaviour {
    private Enemy enemy;
    public GameObject Bar;
    private int enemy_HP;
	// Use this for initialization
	void Start () {
        enemy = GetComponent<Enemy>();
	}
	void CheckHP()
    {
        float temp; 
        enemy_HP = enemy.HP;
        temp = (float)enemy_HP / enemy.MaxHP;
        Bar.transform.localScale = new Vector2(Mathf.Clamp(temp, 0f, 1f), 1f);
    }
	// Update is called once per frame
	void Update () {
        CheckHP();
	}
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Missile_Fire : MonoBehaviour {
    public GameObject Missile; // 미사일 오브젝트
    public Transform[] MissileLocation; // 미사일이 발사될 위치
    public float DelayTime; // 미사일의 CoolTime
    private bool FireState; // 미사일이 발사 가능한지
    private bool FireLocation; // 미사일의 발사 위치 판단

    public int MissileMaxPool; // 메모리 풀에 저장할 미사일 개수
    private MemoryPool MPool; // 메모리 풀
    private GameObject[] MissileArray; // 메모리 풀과 연동하여 사용할 미사일 배열

    /** 게임이 종료되면 자동으로 호출되는 함수 */
    private void OnApplicationQuit() 
    {
        //메모리 풀을 비워줌
        MPool.Dispose();
    }
    // Use this for initialization
    void Start () {
        FireState = true;
        FireLocation = true;

        //메모리 풀을 초기화
        MPool = new MemoryPool();
        // Missile을 MaxPool 만큼 생성
        MPool.Create(Missile, MissileMaxPool);
        // 배열 초기화
        MissileArray = new GameObject[MissileMaxPool];
	}
	// Update is called once per frame
	void Update () {
        FireCheck();
	}
    void FireCheck()
    {
        if (FireState)
        {
            if (Input.GetKey(KeyCode.A))
            {
                StartCoroutine("FireCycleCount");

                // 미사일 풀에서 발사되지 않은 미사일을 찾아서 발사
                for (int i = 0; i < MissileMaxPool; i++)
                {
                    if (MissileArray[i] == null)
                    {
                        // 메모리 풀에서 미사일을 가져온다
                        MissileArray[i] = MPool.NewItem();
                        if (FireLocation) // MissileLocation[0] position 
                        {
                            MissileArray[i].transform.position = MissileLocation[0].transform.position;
                            FireLocation = false;
                        }
                        else // MissileLocation[1] position
                        {
                            MissileArray[i].transform.position = MissileLocation[1].transform.position;
                            FireLocation = true;
                        }
                        break;
                    }
                }
            }
        }

        // 미사일이 발사될때마다 미사일을 메모리 풀을 돌려보내는 것을 체크
        for (int i=0; i< MissileMaxPool; i++)
        {
            if (MissileArray[i])
            {
                if(MissileArray[i].GetComponent<Collider2D>().enabled == false)
                {
                    MissileArray[i].GetComponent<Collider2D>().enabled = true;
                    MPool.RemoveItem(MissileArray[i]);
                    MissileArray[i] = null;
                }
            }
        }
    }
    IEnumerator FireCycleCount()
    {
        FireState = false;
        yield return new WaitForSeconds(DelayTime);
        FireState = true;
    }
}


﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_Move : MonoBehaviour {
    public float speed = 3.0f;
	// Use this for initialization
	void Start () {
		
	}
	// Update is called once per frame
	void Update () {
        Move();
	}
    void Move()
    {
        if (Input.GetKey(KeyCode.UpArrow)) // 윗 방향키를 입력했을때
        {
            transform.Translate(Vector2.up * speed * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.DownArrow)) // 밑 방향키를 입력했을때
        {
            transform.Translate(Vector2.down * speed * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.RightArrow)) // 우측 방향키를 입력했을때
        {
            transform.Translate(Vector2.right * speed * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.LeftArrow)) // 왼쪽 방향키를 입력했을때
        {
            transform.Translate(Vector2.left * speed * Time.deltaTime);
        }
    }
}
